function y = d_sigmoid(s)

y = sigmoid(s)*(1-sigmoid(s));

end