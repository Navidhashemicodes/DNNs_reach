function y = sigmoid(s)

y = 1 / (1+exp(-s))  ;

end