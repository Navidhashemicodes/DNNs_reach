function y = d_tanh(s)

y = 1-tanh(s)^2;


end