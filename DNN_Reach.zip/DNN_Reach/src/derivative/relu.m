function y = relu(s)

y = max(0 , s);

end