function y = d_relu(s)

if s > 0
    y = 1;
elseif s==0
    y = 0.5;
else
    y = 0;
end


end