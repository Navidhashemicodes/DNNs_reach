clear
clc

delete('directions.npz')
delete('Direction_data.mat')
delete('Reduced_dimension.mat')
delete('trained_relu_weights_2h_norm.mat')
verify_CamVid_on_BiSeNet( [360-20,480-20], 17, '0001TP_010290.png', 3, 2100, 150, 8000 , 8000, 0.999  )

delete('directions.npz')
delete('Direction_data.mat')
delete('Reduced_dimension.mat')
delete('trained_relu_weights_2h_norm.mat')
verify_CamVid_on_BiSeNet( [360-20,480-20], 34, '0001TP_010290.png', 3, 2100, 150, 8000 , 8000, 0.999  )

delete('directions.npz')
delete('Direction_data.mat')
delete('Reduced_dimension.mat')
delete('trained_relu_weights_2h_norm.mat')
verify_CamVid_on_BiSeNet( [360-20,480-20], 51, '0001TP_010290.png', 3, 2100, 150, 8000 , 8000, 0.999  )


delete('directions.npz')
delete('Direction_data.mat')
delete('Reduced_dimension.mat')
delete('trained_relu_weights_2h_norm.mat')
verify_CamVid_on_BiSeNet( [360-20,480-20], 68, '0001TP_010290.png', 3, 2100, 150, 8000 , 8000, 0.999  )

delete('directions.npz')
delete('Direction_data.mat')
delete('Reduced_dimension.mat')
delete('trained_relu_weights_2h_norm.mat')
verify_CamVid_on_BiSeNet( [360-20,480-20], 85, '0001TP_010290.png', 3, 2100, 150, 8000 , 8000, 0.999  )

delete('directions.npz')
delete('Direction_data.mat')
delete('Reduced_dimension.mat')
delete('trained_relu_weights_2h_norm.mat')
verify_CamVid_on_BiSeNet( [360-20,480-20], 102, '0001TP_010290.png', 3, 2100, 150, 8000 , 8000, 0.999  )

delete('directions.npz')
delete('Direction_data.mat')
delete('Reduced_dimension.mat')
delete('trained_relu_weights_2h_norm.mat')